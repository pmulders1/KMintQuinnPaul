var class_monster =
[
    [ "Monster", "class_monster.html#a3dfc253fbec8331d42ac13c20bf9425f", null ],
    [ "~Monster", "class_monster.html#a21619ba1759b910cd2fd50d858aab338", null ],
    [ "Draw", "class_monster.html#ab8dc2e4d443d23c46a705aa9bc66d3dd", null ],
    [ "OnCollision", "class_monster.html#a6e4cf2a4533245f65215243ef659b858", null ],
    [ "Update", "class_monster.html#ae3cfc1c225b800d11d7f9ae864687268", null ]
];