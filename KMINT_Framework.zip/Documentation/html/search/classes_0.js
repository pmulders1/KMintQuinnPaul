var searchData=
[
  ['color',['Color',['../struct_color.html',1,'']]]
];
