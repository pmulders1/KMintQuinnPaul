var searchData=
[
  ['monster',['Monster',['../class_monster.html',1,'']]]
];
