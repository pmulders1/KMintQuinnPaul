var searchData=
[
  ['translate',['Translate',['../class_i_game_object.html#a0c27f50dd3783bdc126beb249dc160d0',1,'IGameObject']]]
];
