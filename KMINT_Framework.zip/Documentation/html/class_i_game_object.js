var class_i_game_object =
[
    [ "IGameObject", "class_i_game_object.html#a20daa5a14a79200a4b995ef763e4bbb5", null ],
    [ "CheckCollision", "class_i_game_object.html#a7ca855de4ee1b392926dbd6bdd03f6e3", null ],
    [ "DistanceTo", "class_i_game_object.html#a0ef5e610a6afc8215902853820a7e954", null ],
    [ "DistanceTo", "class_i_game_object.html#ad34f7ba9433ba5e449852593011ffb6a", null ],
    [ "Draw", "class_i_game_object.html#aabf746343989a0a29543a3d6db48b6a4", null ],
    [ "GetBoundingBox", "class_i_game_object.html#aa6ca1547043ec0c072f8dee6f567e2a9", null ],
    [ "GetOffset", "class_i_game_object.html#a133dd7afcf061416f25135e2d29412f9", null ],
    [ "GetSize", "class_i_game_object.html#ace84e8ce58a6886028f2ada293a170c7", null ],
    [ "GetTexture", "class_i_game_object.html#af2a85a8821cbe4305ce92c8bbe8ecf5e", null ],
    [ "OnCollision", "class_i_game_object.html#a31702eed0f78cff5e5d49717751bd39d", null ],
    [ "SetOffset", "class_i_game_object.html#abef2c39177245bdca445db64a1d24be8", null ],
    [ "SetSize", "class_i_game_object.html#a1eddecf9e89fc2df118e2a801bf01875", null ],
    [ "SetTexture", "class_i_game_object.html#a6c4babfa9e8eadd50599e5b7c4dd9e12", null ],
    [ "Translate", "class_i_game_object.html#a0c27f50dd3783bdc126beb249dc160d0", null ],
    [ "Update", "class_i_game_object.html#a4959cd2f80334cfa1a97255082e984cc", null ],
    [ "mApplication", "class_i_game_object.html#a220c4930e5c05f5439a9500ed0a9dbbb", null ],
    [ "mHeight", "class_i_game_object.html#a487f7e17554d9ae5364a7d2a65b3f2fa", null ],
    [ "mTexture", "class_i_game_object.html#a84a1ac4af74782e8538979a821141047", null ],
    [ "mWidth", "class_i_game_object.html#a40428382f876086d82c8d051c5cb268a", null ],
    [ "mX", "class_i_game_object.html#af9b68e07a9421585895fd57958cd4064", null ],
    [ "mY", "class_i_game_object.html#a4aa4eb751cd7e7a2d5c849b68e062cde", null ]
];