var annotated =
[
    [ "Color", "struct_color.html", "struct_color" ],
    [ "FWApplication", "class_f_w_application.html", "class_f_w_application" ],
    [ "IGameObject", "class_i_game_object.html", "class_i_game_object" ],
    [ "Monster", "class_monster.html", "class_monster" ]
];