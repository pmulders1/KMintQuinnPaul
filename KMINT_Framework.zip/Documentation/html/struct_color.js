var struct_color =
[
    [ "Color", "struct_color.html#a9a742cbe9f9f4037f5d9f4e81a9b2428", null ],
    [ "Color", "struct_color.html#ae47bf1bef1dfe52a8300239e46b50122", null ],
    [ "a", "struct_color.html#a5522bf0c5397a8e0e05b0cccc291b510", null ],
    [ "b", "struct_color.html#a24ff460ba4d95b3ff221757e6fd8246e", null ],
    [ "g", "struct_color.html#a6b92bc7134b6e016d2a04813cad97638", null ],
    [ "r", "struct_color.html#a3249a9e784a2f087bde25f9c3cf2700d", null ]
];